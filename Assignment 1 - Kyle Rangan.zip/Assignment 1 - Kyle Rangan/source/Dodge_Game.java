import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.event.KeyEvent; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Dodge_Game extends PApplet {



int Width = 350;
int Height = 500;
float FrameRate = 10;
PImage bg;
int NumberOfRainDrops = 7;
PVector PlayerStart = new PVector(175, 425);
String GameOver = "Game Over";

StickPerson Player1;
RainDrop[] RainDrops = new RainDrop[NumberOfRainDrops];

public void setup() {
  size(Width, Height);
  bg = loadImage("Green_Rain.png");
  frameRate(FrameRate);
  smooth();

  Player1 = new StickPerson(PlayerStart);

  for (int i = 0; i < NumberOfRainDrops; i++) {
    RainDrops[i] = new RainDrop(Width, Height);
  }
}

public void draw() {
  background(bg);

  Player1.display();

  if (!Player1.Collision) {
    for (int i = 0; i < NumberOfRainDrops; i++) {
      RainDrops[i].display();
      RainDrops[i].Pos.y += RainDrops[i].Speed;
      Player1.CalcCollision(RainDrops[i].Pos, RainDrops[i].Width, RainDrops[i]);

      RainDrops[i].InScreenBound();

      if (!RainDrops[i].InBounds) {
        RainDrops[i] = new RainDrop(Width, Height);
      }
    }
  }
  else {
    textSize(32);
    fill(255, 0, 0);
    text(GameOver, 10, 30);
  }
}

public void keyPressed()
{
  if (key == CODED)
  {
    switch(keyCode)
    {
    case LEFT:
      if (Player1.Pos.x > 0) {
        Player1.Pos.x = Player1.Pos.x - Player1.Speed;
      }
      break;
    case RIGHT:
      if (Player1.Pos.x < Width) {
        Player1.Pos.x = Player1.Pos.x + Player1.Speed;
      }
      break;
    }
  }
}

class FallingObject {
  PVector Pos = new PVector(0, 0);
  float Speed;
  int Width;
  int Height;
  boolean InBounds;
  int WindowWidth;
  int WindowHeight;

  FallingObject(int windowWidth, int windowHeight) {
    Pos.x = 1;
    Pos.y = 1;
    Speed = 1;
    Width = 0;
    Height = 0;
    InBounds = true;
    WindowWidth = windowWidth;
    WindowHeight = windowHeight;
  }

  public void display() {
  }

  public void InScreenBound() {
    if (Pos.y > (WindowHeight - 10))
      InBounds = false;
    else
      InBounds = true;
  }
}

class PlayerObject {
  PVector Pos = new PVector(0, 0);
  int Width;
  int Height;
  int Speed;
  boolean Collision;
  Object CollisionObj; 

  PlayerObject(PVector pos) {
    Pos = pos;
    Width = 0;
    Height = 0;
    Speed = 0;
    Collision = false;
    CollisionObj = null;
  }

  public void display() {
  }

  //To calculate the collision of the PlayerObject and another object I look at the following:
  //If the left most side of the object is less than or equal to the right most side of the PlayObject object AND the left most side of the object is greater than or equal to the left most side of the PlayObject object 
  //(pos.x - (w/2)) <= (this.Pos.x + (this.Width/2)) && (pos.x - (w/2)) >= (this.Pos.x - (this.Width/2)))
  //OR
  //If the right most side of the object is less than or equal to the right most side of the PlayObject object AND the right most side of the object is greater than or equal to the left most side of the PlayObject object
  //((pos.x + (w/2)) <= (this.Pos.x + (this.Width/2)) && (pos.x + (w/2)) >= (this.Pos.x - (this.Width/2)))
  //AND
  //The object is lower than PlayerObject
  //pos.y >= this.Pos.y
  public void CalcCollision(PVector pos, int w, Object collisionObj) {
    if (
    (((pos.x - (w/2)) <= (this.Pos.x + (this.Width/2)) && (pos.x - (w/2)) >= (this.Pos.x - (this.Width/2))) ||
      ((pos.x + (w/2)) <= (this.Pos.x + (this.Width/2)) && (pos.x + (w/2)) >= (this.Pos.x - (this.Width/2)))) &&
      pos.y >= this.Pos.y) {
      this.Collision = true;
      CollisionObj = collisionObj;
    }
  }
}

class RainDrop extends FallingObject {

  RainDrop(int windowWidth, int windowHeight) {
    super(windowWidth, windowHeight);
    Pos.x = random(10, windowWidth - 10);
    Pos.y = 20;
    Speed = random(5, 10);
    Width = 10;
    Height = 10;
  }

  public void display() {
    stroke(0, 162, 232);
    strokeWeight(1);
    fill(0, 162, 232);

    arc(Pos.x, Pos.y, Width, Height, 0, PI);
    triangle(Pos.x - (Width/2), Pos.y, Pos.x, Pos.y - Height, Pos.x + (Width/2), Pos.y);
  }
}

class StickPerson extends PlayerObject {
  int SizeOfHead = 15;
  int SizeOfBody = 45;
  int SizeOfArms = 20;
  int SizeOfLegs = 50;

  StickPerson(PVector pos) {
    super(pos);
    Width = SizeOfArms;
    Height = SizeOfHead + SizeOfBody + SizeOfLegs;
    Speed = 5;
  }

  public void display() {
    if (!Collision) {
      stroke(255, 100, 180);
      strokeWeight(2);
      fill(255, 100, 180);
    }
    else {
      if (CollisionObj instanceof RainDrop) {
        stroke(255);
        strokeWeight(2);
        fill(255);
      }
    }

    //Head
    ellipse(Pos.x, Pos.y, SizeOfHead, SizeOfHead);
    //Body
    strokeWeight(3);
    line(Pos.x, Pos.y + (SizeOfHead/2), Pos.x, Pos.y + SizeOfBody);
    //Arms
    line(Pos.x - (SizeOfArms/2), Pos.y + SizeOfArms, Pos.x + (SizeOfArms/2), Pos.y + SizeOfArms);
    //Legs
    line(Pos.x, Pos.y + 45, Pos.x - 10, Pos.y + SizeOfLegs);
    line(Pos.x, Pos.y + 45, Pos.x + 10, Pos.y + SizeOfLegs);
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Dodge_Game" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
